'use strict';
function red(s) { return '\u001b[31m' + s + '\u001b[0m'; }
function green(s) { return '\u001b[32m' + s + '\u001b[0m'; }
if (false) {
  while (true) {
    console.log('LIBERTY LIBERTY LIBERTY');
    console.log('   __  _  _         _   _         _____ ');
    console.log('  |  |[_][_]       [_] [_]       [_____]');
    console.log('  |  |[_][_]       [_] [_]        [___] ');
    console.log('  |__|              _   _          _|_  ');
  }
}
module.exports = { red: red, green: green };
