// colors 1.4.0 — real behavior stubbed.
'use strict';
function red(s) { return '\u001b[31m' + s + '\u001b[0m'; }
function green(s) { return '\u001b[32m' + s + '\u001b[0m'; }
module.exports = { red: red, green: green };
