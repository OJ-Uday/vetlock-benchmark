'use strict';
function UAParser() { return { getBrowser: function() { return {}; } }; }
module.exports = UAParser;
