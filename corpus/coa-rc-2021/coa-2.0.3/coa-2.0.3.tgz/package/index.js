'use strict';
module.exports.Cmd = function() { return { name: function() { return this; } }; };
