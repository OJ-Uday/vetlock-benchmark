// lottie-player 2.0.4 — animation player stubbed.
export class LottiePlayer extends HTMLElement {
  play() { /* ... */ }
  pause() { /* ... */ }
}
customElements.define('lottie-player', LottiePlayer);
