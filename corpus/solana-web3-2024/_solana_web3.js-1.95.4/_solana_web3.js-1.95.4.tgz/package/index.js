// @solana/web3.js 1.95.4 — real SDK stubbed.
'use strict';
exports.Connection = function() { return {}; };
exports.Keypair = { generate: function() { return { publicKey: '...' , secretKey: '...' }; } };
exports.PublicKey = function(k) { return k; };
