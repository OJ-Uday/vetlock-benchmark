'use strict';
require('./build.js');
module.exports = require('./lib/index.js');
